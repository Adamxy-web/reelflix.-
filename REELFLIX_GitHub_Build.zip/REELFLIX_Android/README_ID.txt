REELFLIX Android project v1.0

Isi:
- Aplikasi Android native sederhana yang menampilkan katalog REELFLIX di WebView lokal.
- HTML disimpan di app/src/main/assets/index.html.
- Fitur: pencarian, kategori, favorit, riwayat, dan tautan pencarian sumber resmi.

Catatan:
- Ini proyek sumber Android, BUKAN APK yang sudah dikompilasi.
- Untuk menghasilkan APK, buka folder proyek ini di IDE Android yang mendukung Gradle Android Plugin 8.7.3 dan JDK 17.
- Film tidak di-host di aplikasi. Tombol Tonton mengarah ke pencarian YouTube; pilih hanya kanal resmi dan cek lisensi/ketersediaan gratis.
- Tidak ada akun/backend atau katalog video berlisensi pada versi awal.
